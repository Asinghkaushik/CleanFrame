import math
all_combinations=[]
min_cost=1000000000

def pair_exists(my_pair,rel):
    for each in rel:
        if each[0]==my_pair[0] and each[1]==my_pair[1]:
            return True
        if each[1]==my_pair[0] and each[0]==my_pair[1]:
            return True
    return False

def combination_is_safe(combination,rel):
    for i in range(len(combination)-1):
        my_pair=[combination[i],combination[i+1]]
        if pair_exists(my_pair,rel)==False:
            return False
    return True

def backtrack_combinations(students,left,right,rel): 
    if left==right:
        combination=''.join(students)
        if combination_is_safe(combination,rel)==True:
            all_combinations.append(combination)
        return 1
    for i in range(left,right+1): 
        students[left],students[i]=students[i],students[left] 
        backtrack_combinations(students,left+1,right,rel) 
        students[left],students[i]=students[i],students[left]
    return 0

def check_min_cost(combinations,relations):
    for each in combinations:
        check_s    
    

t=int(input())
for each in range(t):
    n=int(input())
    students=[]
    for i in range(n):
        students.append(input())
    r=int(input())
    rel=[]
    for i in range(r):
        rel.append(input().split(' '))
        # rel[i].append(0)
    for i in range(r):
        rel[i][2]=int(rel[i][2])
        # rel[i][3]=int(rel[i][3])
    all_combinations=[]
    backtrack_combinations(students,0,n-1,rel)
    print(all_combinations)
    min_cost=1000000000
    get_index=check_min_cost(all_combinations,rel)