$(document).ready(function() {
    $('#message').fadeIn('slow', function() {
        $('#message').delay(8000).fadeOut();
    });
});