// function set_class(id){
//   document.getElementById(id).className += " active";
// }
// document.getElementById("first").addEventListener("click", function() {
//   if ( document.getElementById("first").classList.contains('active') ){
//     document.getElementById("first").classList.remove('active');
//   }
//   else{
//       document.getElementById("first").classList.add('active');
//   }
// });
