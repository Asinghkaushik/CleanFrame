$(document).ready(function() {
    $('#message').fadeIn('slow', function() {
        $('#message').delay(5000).fadeOut();
    });
});