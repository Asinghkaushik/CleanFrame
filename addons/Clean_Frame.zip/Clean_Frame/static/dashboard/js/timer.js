$(document).ready(function() {
    $('#message').fadeIn('slow', function() {
        $('#message').delay(500).fadeOut(2500);
    });
});