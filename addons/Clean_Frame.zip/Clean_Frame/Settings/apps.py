from django.apps import AppConfig


class SettingsConfig(AppConfig):
    name = 'Settings'
